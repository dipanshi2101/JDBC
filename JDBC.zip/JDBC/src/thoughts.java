import java.util.*;

public class thoughts {

    public void enterThoughts() {

    }
}
